# DisplayCords
Display your current position in PopUp or Tip
