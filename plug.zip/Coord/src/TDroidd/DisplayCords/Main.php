<?php
namespace TDroidd\DisplayCords;
use pocketmine\Player;
use pocketmine\entity;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\command\Command;
class Main extends PluginBase implements Listener {
	/**
	 * OnEnable
	 *
	 * (non-PHPdoc)
	 * 
	 * @see \pocketmine\plugin\PluginBase::onEnable()
	 */	
	 public function onEnable(){
		$this->saveDefaultConfig();
		$this->reloadConfig();
		$this->getServer()->getPluginManager()->registerEvents($this,$this);
		$this->getLogger()->info("§4DisplayCords Enabled!");
		}
	public function onMove(PlayerMoveEvent $event){
	$cfg=$this->getConfig();
	$enable=$cfg->get("Enable");
	$p = $event->getPlayer();
	$x = $p->getFloorX();
	$y = $p->getFloorY();
	$z = $p->getFloorZ();
	$level = $p->getLevel()->getName();
	if($enable === true){
	$p->sendPopUp("§l§4Ваши координаты $x $y $z");
}
}
		public function onCommand(CommandSender $sender, Command $command, $label, array $args){
			switch($command->getName()){
				case "xyz":
					if($sender instanceof Player){
						
				$x = $sender->getFloorX();
				$y = $sender->getFloorY();
				$z = $sender->getFloorZ();
				$level = $sender->getLevel()->getName();
						
					$sender->sendMessage("§l§4Ваши координаты $x $y $z");
					return true;
				}
			}
		}
	/**
	 * OnDisable 
	 * (non-PHPdoc)
	 * 
	 * @see \pocketmine\plugin\PluginBase::onDisable()
	 */
	public function onDisable() {
		$this->getLogger()->info("§4DisplayCords Disabled!");
	}
}
