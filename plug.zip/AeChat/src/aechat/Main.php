<?php
namespace aechat;

use pocketmine\plugin\PluginBase;

use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as CLR;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;

use pocketmine\Player;
use pocketmine\command\ConsoleCommandSender;

class Main extends PluginBase implements Listener {
	
	/** @var string */
	private $L;
	private $G;
	private $A;
	private $cache = null;
	
	/** @var int */
	private $radius = null;
	
	/** @var \pocketmine\command\ConsoleCommandSender */
	private $server = null;
	
	public function onEnable() {
		$this->getLogger()->info(CLR::GOLD . 'AeChat загружается...');
		
		@mkdir($this->getDataFolder());
		
		if (!file_exists($this->getDataFolder() . 'config.yml'))
			file_put_contents($this->getDataFolder() . 'config.yml', $this->getResource('config.yml'));
		$data = (new Config($this->getDataFolder() . 'config.yml', Config::YAML))->getAll();
		
		$this->L = $data['local'];
		$this->G = $data['global'];
		$this->A = $data['admin'];
		$this->radius = (int) $data['radius'];
		
		$this->server = new ConsoleCommandSender();
		
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		
		$this->getLogger()->info(CLR::GOLD . 'AeChat загружен!');
	}
	
	/**
	 * @param PlayerChatEvent $e
	 * @priority LOWEST
	 */
	public function partOne(PlayerChatEvent $e) {
		$sender = $e->getPlayer();
		$msg = $e->getMessage();
		if ($msg{0} === '!') {
			$e->setMessage(substr($msg, 1));
			$this->cache = $this->G;
		} else {//cc
			if($msg{0} === '@'){//bb
				if($sender->hasPermission("ae.achat")){
					$e->setMessage(substr($msg, 1));
					$sendTo = [$this->server];
					foreach ($sender->getLevel()->getPlayers() as $player) {
						if($player->hasPermission("ae.achat")){
							$sendTo[] = $player;
						}
					}
					$e->setRecipients($sendTo);
			        $this->cache = $this->A;
				   
				}else{//aa
					$sendTo = [$this->server];
                    $x = $sender->getFloorX();
                    $y = $sender->getFloorY();
                    $z = $sender->getFloorZ();
                    $r = $this->radius;

                    foreach ($sender->getLevel()->getPlayers() as $player) {
				         if (
					        ($x - $r) <= $player->getX() && ($x + $r) >= $player->getX() && 
					        ($y - $r) <= $player->getY() && ($y + $r) >= $player->getY() && 
					        ($z - $r) <= $player->getZ() && ($z + $r) >= $player->getZ()
				            ) {
					           $sendTo[] = $player;
				         }
			         }
			
			$e->setRecipients($sendTo);
			$this->cache = $this->L;
				}//aa
				
			}else{
$sendTo = [$this->server];
                    $x = $sender->getFloorX();
                    $y = $sender->getFloorY();
                    $z = $sender->getFloorZ();
                    $r = $this->radius;

                    foreach ($sender->getLevel()->getPlayers() as $player) {
				         if (
					        ($x - $r) <= $player->getX() && ($x + $r) >= $player->getX() && 
					        ($y - $r) <= $player->getY() && ($y + $r) >= $player->getY() && 
					        ($z - $r) <= $player->getZ() && ($z + $r) >= $player->getZ()
				            ) {
					           $sendTo[] = $player;
				         }
			         }
			
			$e->setRecipients($sendTo);
			$this->cache = $this->L;
            }//bb
		}//cc
	}
	
	/**
	 * @param PlayerChatEvent $e
	 * @priority HIGHEST
	 */
	public function partTwo(PlayerChatEvent $e) {
		$e->setFormat($this->cache . $this->getServer()->getLanguage()->translateString($e->getFormat(), [$e->getPlayer()->getDisplayName(), $e->getMessage()]));
	}
	
}
?>
