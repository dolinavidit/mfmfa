# WorldEdit-Plus
WorldEdit Plus
BaseOn WorldEditor v1.0.3

現在使えるもの
//helpで確認

Todo
//tree
//lake
//lavalake
//house
//flower
//etc..
